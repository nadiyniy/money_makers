import styled from 'styled-components';

export const StyledBurgerBtn = styled.div`
  @media (min-width: 768.1px) {
    display: none;
  }
  button {
  }
`;
