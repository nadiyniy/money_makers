
const AllUsersTab = () => {
  return <div>AllUsersTab</div>;
};

export default AllUsersTab;
